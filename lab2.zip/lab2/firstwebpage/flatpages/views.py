from django.shortcuts import render
from django.http import HttpResponse
from django import template
from django.shortcuts import render

def hello(request):
     return HttpResponse(u'Hello, World!', content_type="text/plaindef")
def home(request):
     return render(request, 'templates/index.html')

